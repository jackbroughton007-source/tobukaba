/*
  SUPABASE SETUP
  1. Create a project at https://supabase.com
  2. In Project Settings > API, copy the Project URL and publishable/anon key.
  3. Paste them below. The anon key is designed to be used in a browser; the
     database rules in supabase-schema.sql protect each user's data.
*/
const SUPABASE_URL = "https://snayzoqyylcnmclxjfpd.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_XsVrmjyipMMwb7vayFxCZw_8CT-vU7-";
const supabaseConfigured =
    !SUPABASE_URL.includes("PASTE_YOUR") &&
    !SUPABASE_ANON_KEY.includes("PASTE_YOUR") &&
    window.supabase;
const supabaseClient = supabaseConfigured
    ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : null;

let currentUser = null;
let cloudSaveTimer = null;
let isLoadingCloudData = false;

let userSettings = normaliseSettings(JSON.parse(localStorage.getItem("kanjiSRSSettings")));

const LEECH_LIMIT = 8;

/*
Adaptive SRS. Each word carries its own interval and ease. The 365-day cap
keeps long-term vocabulary in rotation instead of permanently retiring it.
*/
const SRS = {
    version: 2,
    maxInterval: 365,
    longTermInterval: 60,
    initialEase: 2.3,
    minimumEase: 1.3,
    maximumEase: 3,
    fuzz: 0.05
};

const DAY_MS = 24 * 60 * 60 * 1000;

function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
}

function newSrsFields() {
    return {
        srsVersion: SRS.version,
        intervalDays: 0,
        easeFactor: SRS.initialEase,
        repetitions: 0,
        lapses: 0,
        reviewLog: [],
        correctCount: 0,
        failCount: 0,
        dueDate: today(),
        nextReviewAt: new Date().toISOString(),
        lastReviewed: null,
        lastReviewedAt: null
    };
}

function legacyInterval(word) {
    const savedInterval = Number(word.intervalDays);
    if (Number.isFinite(savedInterval) && savedInterval >= 0) {
        return clamp(Math.round(savedInterval), 0, SRS.maxInterval);
    }

    const legacyProgress = clamp(Number(word.correctCount) || 0, 0, 5);
    const legacyDue = String(word.nextReviewAt || word.dueDate || "");
    if (legacyProgress >= 5 || legacyDue.startsWith("9999-")) return 90;

    if (word.lastReviewed && word.nextReviewAt) {
        const last = new Date(`${word.lastReviewed}T00:00:00`).getTime();
        const next = new Date(word.nextReviewAt).getTime();
        const inferred = Math.round((next - last) / DAY_MS);
        if (Number.isFinite(inferred) && inferred > 0) {
            return clamp(inferred, 1, SRS.maxInterval);
        }
    }

    return [0, 1, 3, 7, 14, 90][legacyProgress];
}

function normaliseWord(word) {
    const legacyProgress = clamp(Number(word.correctCount) || 0, 0, 5);
    const wasPermanentlyRetired = legacyProgress >= 5 ||
        String(word.nextReviewAt || word.dueDate || "").startsWith("9999-");
    const intervalDays = legacyInterval(word);
    const lastReviewed = word.lastReviewed ?? null;
    const fallbackLastReviewedTime = lastReviewed
        ? new Date(`${lastReviewed}T00:00:00`).getTime()
        : NaN;
    const fallbackLastReviewedAt = Number.isFinite(fallbackLastReviewedTime)
        ? new Date(fallbackLastReviewedTime).toISOString()
        : null;

    let nextReviewAt = word.nextReviewAt ?? (word.dueDate
        ? new Date(`${word.dueDate}T00:00:00`).toISOString()
        : new Date().toISOString());

    // Old Burned cards were hidden until year 9999. Bring them back gently,
    // once, at the Long-term cadence instead of making them due immediately.
    if (Number(word.srsVersion) < SRS.version && wasPermanentlyRetired) {
        nextReviewAt = new Date(Date.now() + intervalDays * DAY_MS).toISOString();
    }

    const nextReviewTime = new Date(nextReviewAt).getTime();
    if (!Number.isFinite(nextReviewTime)) nextReviewAt = new Date().toISOString();

    const repetitions = Math.max(0, Number(word.repetitions) || legacyProgress);
    const failCount = Math.max(0, Number(word.failCount) || 0);

    return {
        ...word,
        srsVersion: SRS.version,
        intervalDays,
        easeFactor: clamp(Number(word.easeFactor) || SRS.initialEase, SRS.minimumEase, SRS.maximumEase),
        repetitions,
        lapses: Math.max(0, Number(word.lapses) || failCount),
        reviewLog: Array.isArray(word.reviewLog) ? word.reviewLog : [],
        // Kept for backwards-compatible backups; scheduling no longer uses it.
        correctCount: Math.min(5, repetitions),
        failCount,
        dueDate: todayFromDate(new Date(nextReviewAt)),
        nextReviewAt,
        jlpt: String(word.jlpt || "").trim() || "Unknown",
        category: String(word.category || "").trim() || "No Category",
        pos: word.pos ?? "Other",
        lastReviewed,
        lastReviewedAt: word.lastReviewedAt ?? fallbackLastReviewedAt
    };
}


/* =========================================================
   DEFAULT WORDS
========================================================= */

const defaultWords = [

{
english:"Police",
kanji:"警察",
hiragana:"けいさつ",
jlpt:"N3",
category:"Daily Life",
pos:"Noun"
},

{
english:"Youth",
kanji:"青春",
hiragana:"せいしゅん",
jlpt:"N2",
category:"Daily Life",
pos:"Noun"
},

{
english:"Certificate",
kanji:"証明書",
hiragana:"しょうめいしょ",
jlpt:"N2",
category:"Daily Life",
pos:"Noun"
},

{
english:"Crybaby",
kanji:"泣き虫",
hiragana:"なきむし",
jlpt:"N2",
category:"Daily Life",
pos:"Noun"
},

{
english:"Detailed",
kanji:"詳しい",
hiragana:"くわしい",
jlpt:"N3",
category:"Daily Life",
pos:"い-adjective"
},

{
english:"Salt",
kanji:"塩",
hiragana:"しお",
jlpt:"N5",
category:"Food",
pos:"Noun"
},

{
english:"Failure",
kanji:"失敗",
hiragana:"しっぱい",
jlpt:"N3",
category:"Daily Life",
pos:"Noun"
},

{
english:"Same as ever",
kanji:"相変わらず",
hiragana:"あいかわらず",
jlpt:"N2",
category:"Expressions",
pos:"Expression"
},

{
english:"Signature",
kanji:"署名",
hiragana:"しょめい",
jlpt:"N2",
category:"Daily Life",
pos:"Noun"
},

{
english:"Empty seat",
kanji:"空席",
hiragana:"くうせき",
jlpt:"N2",
category:"Daily Life",
pos:"Noun"
},

{
english:"Atom",
kanji:"原子",
hiragana:"げんし",
jlpt:"N2",
category:"Science",
pos:"Noun"
}

];


/* =========================================================
   DATA
========================================================= */

function normaliseWords(savedWords) {

    if (!Array.isArray(savedWords)) {
        return defaultWords.map(word => ({ ...word, ...newSrsFields() }));
    }

    return savedWords.map(normaliseWord);
}

function normaliseStats(savedStats) {
    const source = savedStats && typeof savedStats === "object" ? savedStats : {};
    return {
        totalReviews: Number(source.totalReviews) || 0,
        successfulReviews: Number(source.successfulReviews) || 0,
        totalFailures: Number(source.totalFailures) || 0,
        totalLessons: Number(source.totalLessons) || 0,
        xp: Number(source.xp) || 0,
        reviewHistory: source.reviewHistory || {},
        lessonHistory: source.lessonHistory || {},
        lastStudyDate: source.lastStudyDate ?? null,
        streak: Number(source.streak) || 0
    };
}

function normaliseSettings(savedSettings) {
    const source = savedSettings && typeof savedSettings === "object" ? savedSettings : {};
    return {
        dailyGoal: Math.max(1, Math.min(500, parseInt(source.dailyGoal, 10) || DEFAULT_SETTINGS.dailyGoal)),
        chunkSize: Math.max(1, Math.min(100, parseInt(source.chunkSize, 10) || DEFAULT_SETTINGS.chunkSize)),
        gardenState: normaliseGardenState(source.gardenState)
    };
}

let words = normaliseWords(JSON.parse(localStorage.getItem("kanjiWords")));
// Persist local migrations immediately so a legacy Long-term due date does
// not restart on each reload before the learner next reviews a word.
localStorage.setItem("kanjiWords", JSON.stringify(words));


/* =========================================================
   USER STATS
========================================================= */

let stats = normaliseStats(JSON.parse(localStorage.getItem("kanjiStats")));


/* =========================================================
   QUIZ VARIABLES
========================================================= */

let quizWords = [];
// Number of distinct cards originally loaded into this session.
// Relearning retries do not increase this count.
let quizOriginalCount = 0;

 // Cards rated Hard/Again are placed back into the current session.
// The retry is a confirmation attempt: it does not give the card a
// second SRS progression step. It must be passed before the session ends.
let quizRelearningIndexes = new Set();

let quizIndex = 0;
// The active queue is always explicit: untouched words are lessons and
// previously learned, scheduled words are reviews.
let quizMode = "reviews";
let lastQuizState = null;


/* =========================================================
   DATE FUNCTIONS
========================================================= */

function today() {

    const d = new Date();

    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");

    return `${y}-${m}-${day}`;

}


function addDays(dateString, days) {

    const date = new Date(dateString + "T00:00:00");

    date.setDate(date.getDate() + days);

    return todayFromDate(date);

}


function todayFromDate(date) {

    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${day}`;

}


function setNextReview(word, intervalDays, reviewedAt = new Date()) {

    const safeInterval = clamp(Math.round(intervalDays), 1, SRS.maxInterval);
    const next = new Date(reviewedAt.getTime() + safeInterval * DAY_MS);
    word.intervalDays = safeInterval;
    word.nextReviewAt = next.toISOString();
    word.dueDate = todayFromDate(next);

}


function isLongTerm(word) {
    const hasBeenReviewed = Boolean(word.lastReviewedAt || word.lastReviewed) ||
        Number(word.repetitions) > 0;
    return hasBeenReviewed && Number(word.intervalDays) >= SRS.longTermInterval;
}


function isDue(word) {

    const next = word.nextReviewAt
        ? new Date(word.nextReviewAt).getTime()
        : new Date((word.dueDate || today()) + "T00:00:00").getTime();

    return Number.isFinite(next) && next <= Date.now();

}


function isLeech(word) {

    return word.failCount >= LEECH_LIMIT;

}

function fuzzInterval(interval, randomValue = Math.random()) {
    const rounded = Math.round(interval);
    if (rounded < 4 || rounded >= SRS.maxInterval) {
        return clamp(rounded, 1, SRS.maxInterval);
    }

    const boundedRandom = clamp(Number(randomValue) || 0, 0, 1);
    const factor = 1 - SRS.fuzz + boundedRandom * SRS.fuzz * 2;
    return clamp(Math.round(interval * factor), 1, SRS.maxInterval);
}

function calculateNextInterval(word, rating, reviewedAt = new Date(), randomValue = Math.random()) {
    const previousInterval = clamp(Number(word.intervalDays) || 0, 0, SRS.maxInterval);
    const ease = clamp(Number(word.easeFactor) || SRS.initialEase, SRS.minimumEase, SRS.maximumEase);
    const repetitions = Math.max(0, Number(word.repetitions) || 0);
    const previousReviewTime = word.lastReviewedAt
        ? new Date(word.lastReviewedAt).getTime()
        : NaN;
    const elapsedDays = Number.isFinite(previousReviewTime)
        ? Math.max(0, (reviewedAt.getTime() - previousReviewTime) / DAY_MS)
        : previousInterval;
    const overdueDays = Math.max(0, elapsedDays - previousInterval);

    let interval;
    if (rating === "again") {
        interval = previousInterval <= 1 ? 1 : previousInterval * 0.25;
    } else if (rating === "hard") {
        interval = previousInterval >= SRS.maxInterval
            ? previousInterval * 0.8
            : previousInterval < 1
                ? 1
                : Math.max(previousInterval + 1, previousInterval * 1.2);
    } else if (rating === "good") {
        interval = previousInterval < 1
            ? 1
            : previousInterval === 1 && repetitions <= 1
                ? 3
                : previousInterval * ease + overdueDays * 0.5;
    } else if (rating === "easy") {
        interval = previousInterval < 1
            ? 3
            : previousInterval === 1 && repetitions <= 1
                ? 7
                : previousInterval * ease * 1.3 + overdueDays;
    } else {
        throw new Error(`Unknown SRS rating: ${rating}`);
    }

    return fuzzInterval(interval, randomValue);
}

function applySrsRating(word, rating, reviewedAt = new Date(), randomValue = Math.random(), activity = "review") {
    const previousInterval = clamp(Number(word.intervalDays) || 0, 0, SRS.maxInterval);
    const nextInterval = calculateNextInterval(word, rating, reviewedAt, randomValue);
    let ease = clamp(Number(word.easeFactor) || SRS.initialEase, SRS.minimumEase, SRS.maximumEase);

    const isLesson = activity === "lesson";

    if (rating === "again") {
        ease -= 0.2;
        // Not knowing a word on first exposure is expected. It still receives
        // a short first interval, but it is not a lapse or problem-word failure.
        if (!isLesson) {
            word.failCount = Math.max(0, Number(word.failCount) || 0) + 1;
            word.lapses = Math.max(0, Number(word.lapses) || 0) + 1;
        }
    } else {
        if (rating === "hard") ease -= 0.1;
        if (rating === "easy") ease += 0.1;
        word.repetitions = Math.max(0, Number(word.repetitions) || 0) + 1;
    }

    word.easeFactor = Math.round(clamp(ease, SRS.minimumEase, SRS.maximumEase) * 100) / 100;
    word.correctCount = Math.min(5, Math.max(0, Number(word.repetitions) || 0));
    word.lastReviewed = todayFromDate(reviewedAt);
    word.lastReviewedAt = reviewedAt.toISOString();
    setNextReview(word, nextInterval, reviewedAt);

    if (!Array.isArray(word.reviewLog)) word.reviewLog = [];
    word.reviewLog.push({
        reviewedAt: reviewedAt.toISOString(),
        rating,
        activity,
        previousInterval,
        nextInterval,
        easeFactor: word.easeFactor
    });

    return nextInterval;
}


/* =========================================================
   SAVE
========================================================= */

function saveData() {

    synchroniseGardenState();

    localStorage.setItem(
        "kanjiWords",
        JSON.stringify(words)
    );

    localStorage.setItem(
        "kanjiStats",
        JSON.stringify(stats)
    );

    localStorage.setItem("kanjiSRSSettings", JSON.stringify(userSettings));

    queueCloudSave();

}

function setSyncStatus(message) {
    const status = document.getElementById("syncStatus");
    if (status) status.textContent = message;
}

function setAuthMessage(message) {
    const target = document.getElementById("authMessage");
    if (target) target.textContent = message;
}

function showAuthenticatedApp() {
    document.getElementById("authView").hidden = true;
    document.getElementById("appShell").hidden = false;
    document.getElementById("heroNavigation").hidden = false;
    document.getElementById("accountEmail").textContent = currentUser.email || "your account";
    showPage("dashboard");
}

function showAuthScreen(message = "") {
    document.getElementById("appShell").hidden = true;
    document.getElementById("heroNavigation").hidden = true;
    document.getElementById("authView").hidden = false;
    setAuthMessage(message);
}

function queueCloudSave() {
    if (!supabaseClient || !currentUser || isLoadingCloudData) return;
    clearTimeout(cloudSaveTimer);
    setSyncStatus("Saving…");
    cloudSaveTimer = setTimeout(saveToCloud, 500);
}

async function saveToCloud() {
    if (!supabaseClient || !currentUser || isLoadingCloudData) return;

    synchroniseGardenState();

    setSyncStatus("Saving…");
    const { error } = await supabaseClient
        .from("kanji_srs_profiles")
        .upsert({
            user_id: currentUser.id,
            words,
            stats,
            settings: userSettings,
            updated_at: new Date().toISOString()
        }, { onConflict: "user_id" });

    setSyncStatus(error ? "Could not sync — changes remain on this device." : "Synced");
}

async function loadCloudData() {
    if (!supabaseClient || !currentUser) return;

    isLoadingCloudData = true;
    setSyncStatus("Loading your study data…");
    const { data, error } = await supabaseClient
        .from("kanji_srs_profiles")
        .select("words, stats, settings")
        .eq("user_id", currentUser.id)
        .maybeSingle();

    if (error) {
        isLoadingCloudData = false;
        showAuthScreen("Your account was found, but the study-data table is not ready. Run supabase-schema.sql in Supabase's SQL Editor.");
        return;
    }

    let cloudDataNeededSrsMigration = false;
    let cloudDataNeededGardenMigration = false;
    if (data) {
        cloudDataNeededSrsMigration = Array.isArray(data.words) &&
            data.words.some(word => Number(word.srsVersion) < SRS.version);
        cloudDataNeededGardenMigration = !data.settings?.gardenState ||
            Number(data.settings.gardenState.version || 1) < GARDEN_STATE_VERSION;
        words = normaliseWords(data.words);
        stats = normaliseStats(data.stats);
        userSettings = normaliseSettings(data.settings);
        localStorage.setItem("kanjiWords", JSON.stringify(words));
        localStorage.setItem("kanjiStats", JSON.stringify(stats));
        localStorage.setItem("kanjiSRSSettings", JSON.stringify(userSettings));
    }

    isLoadingCloudData = false;
    showAuthenticatedApp();

    // First login on an existing installation safely migrates its local data.
    if (!data || cloudDataNeededSrsMigration || cloudDataNeededGardenMigration) await saveToCloud();
    else setSyncStatus("Synced");
}

function readCredentials() {
    return {
        email: document.getElementById("authEmail").value.trim(),
        password: document.getElementById("authPassword").value
    };
}

async function signIn() {
    if (!supabaseClient) return;
    const { email, password } = readCredentials();
    if (!email || !password) return setAuthMessage("Enter your email address and password.");
    setAuthMessage("Signing in…");
    const { error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) setAuthMessage(error.message);
}

async function signUp() {
    if (!supabaseClient) return;
    const { email, password } = readCredentials();
    if (!email || password.length < 6) return setAuthMessage("Use an email address and a password of at least 6 characters.");
    setAuthMessage("Creating your account…");
    const { data, error } = await supabaseClient.auth.signUp({ email, password });
    if (error) return setAuthMessage(error.message);
    setAuthMessage(data.session ? "Account created. Loading your data…" : "Check your email to confirm your account, then sign in.");
}

async function resetPassword() {
    if (!supabaseClient) return;
    const email = document.getElementById("authEmail").value.trim();
    if (!email) return setAuthMessage("Enter your email address first.");
    const { error } = await supabaseClient.auth.resetPasswordForEmail(email, { redirectTo: window.location.href });
    setAuthMessage(error ? error.message : "Password-reset instructions have been sent if that account exists.");
}

async function signOut() {
    clearTimeout(cloudSaveTimer);
    await saveToCloud();
    await supabaseClient.auth.signOut();
}

async function initialiseAuthentication() {
    if (!supabaseClient) {
        showAuthScreen("Add your Supabase Project URL and publishable/anon key in the SUPABASE SETUP section of this file.");
        return;
    }

    const { data: { session } } = await supabaseClient.auth.getSession();
    if (session) {
        currentUser = session.user;
        await loadCloudData();
    } else {
        showAuthScreen();
    }

    supabaseClient.auth.onAuthStateChange(async (_event, session) => {
        if (session && (!currentUser || session.user.id !== currentUser.id)) {
            currentUser = session.user;
            await loadCloudData();
        } else if (!session) {
            currentUser = null;
            showAuthScreen();
        }
    });

}




initialiseAuthentication();
